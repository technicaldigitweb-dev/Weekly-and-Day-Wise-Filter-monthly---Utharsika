---
name: ph-rule-validator
description: >
  Use this skill whenever the user asks to validate a SKU or list of SKUs against the
  first 5 FBM Portfolio Holder business rules (BL-01 through BL-05). Triggers include:
  "check SKU", "validate SKU", "run validation", "check first 5 rules", "is this SKU
  healthy", "run PH checks", "check organic performance", "check margin", "check NNV".
  This skill connects to the database via the postgres:execute_sql MCP tool, fetches live values for
  the given SKU(s), evaluates all 5 conditions, and returns a structured result with
  status, restore action, kill action, and next-step instructions per rule.
---

# SKU based question threshold validator

## Purpose

Run the first 5 FBM Portfolio Holder business rules against a given SKU (or list of SKUs).
For each rule, output:
- **PASS / WARN / KILL** status
- Current metric value vs threshold
- RESTORE action (if triggered)
- KILL action (if kill condition met)
- What to do next (review period details, deadlines, escalation)

---

## Step 1 — Identify the SKU(s)

Extract the SKU(s) from the user's message. If none are given, ask:
> "Which SKU (or list of SKUs) would you like me to validate?"

Accept: single SKU string, comma-separated list, or array.

---

## Step 2 — Fetch BLOS Threshold Values via MCP

Use the **`postgres:execute_sql`** MCP tool to fetch all BLOS keys needed for rules BL-01 to BL-05.

> **NOTE:** The exact database name, table name, and column names for BLOS keys
> are defined in the separate BLOS key mapping skill. This skill assumes that skill
> has already resolved the correct query path. If not available, prompt the user:
> "Please provide the BLOS table/column where threshold keys are stored."

### BLOS Keys Required (BL-01 to BL-05)

| Rule | BLOS Key Names |
|------|---------------|
| BL-01 CTR | `organic_ctr_floor_warning`, `organic_ctr_min_impressions`, `organic_ctr_review_period_days`, `organic_ctr_recovery_target`, `organic_ctr_recovery_window_days`, `organic_ctr_kill_threshold`, `organic_ctr_kill_consecutive_days` |
| BL-02 CVR | `cvr_floor_warning_for_below_aov`, `cvr_floor_warning_for_above_aov`, `cvr_min_clicks`, `cvr_review_period_days`, `cvr_recovery_target_for_below_aov`, `cvr_recovery_target_for_above_aov`, `cvr_recovery_window_days`, `cvr_kill_for_below_aov`, `cvr_kill_for_above_aov`, `cvr_min_clicks_for_kill`, `cvr_kill_period_days` |
| BL-03 Impressions | `impression_decline_trigger_pct`, `impression_review_period_days`, `impression_kill_decline_pct`, `impression_kill_no_recovery_days` |
| BL-04 Margin | `fbm_organic_margin_floor`, `cogs_pct`, `vat_rate_pct`, `amazon_referral_fee_pct`, `margin_restore_window_days`, `margin_kill_deadline_days` |
| BL-05 NNV | `nnv_consecutive_days`, `nnv_kill_review_deadline_days`, `nnv_instant_kill_threshold` |

---

## Step 3 — Fetch SKU Metrics via MCP

Use **`postgres:execute_sql`** to fetch the following live values per SKU.
> The exact table/column names for SKU metrics are defined in the BLOS key mapping skill.
> This skill does not hardcode table names — fetch them from the mapping skill if needed.

### Metrics Required per SKU

| Rule | Metrics Needed |
|------|---------------|
| BL-01 CTR | `ctr` (last 14 days), `impressions` (last 14 days), `days_since_listing` |
| BL-02 CVR | `cvr` (last 14 days), `aov` (30-day avg), `clicks` (last 14 days) |
| BL-03 Impressions | `impressions_current_30d`, `impressions_prev_30d`, current month |
| BL-04 Margin | `selling_price`, `postage_cost`, computed `organic_margin_pct` = `(1 - vat_rate_pct - cogs_pct - amazon_referral_fee_pct) - (postage_cost / selling_price)` |
| BL-05 NNV | `revenue_30d`, `vat_30d`, `cogs_30d`, `referral_fee_30d`, `postage_30d`, `days_negative` |

---

## Step 4 — Evaluate Each Rule

Evaluate each of the 5 rules in order. For each rule, apply the condition logic exactly as
defined in the CSV. Use fetched BLOS values as thresholds. Use fetched SKU metrics as inputs.

---

### BL-01 — ORGANIC CTR COLLAPSE

**Condition (WARN):**
```
IF ctr < organic_ctr_floor_warning
AND impressions >= organic_ctr_min_impressions
AND days >= organic_ctr_review_period_days
→ STATUS: WARN
```

**Condition (KILL):**
```
IF ctr < organic_ctr_kill_threshold
AND days >= organic_ctr_kill_consecutive_days
→ STATUS: KILL
```

**RESTORE condition:**
```
IF ctr >= organic_ctr_recovery_target
AND days <= organic_ctr_recovery_window_days
→ STATUS: RECOVERED
```

**Restore Action (if WARN):**
Audit main image and title. Coordinate with PPC team if Sponsored Products are running
on this SKU — low organic CTR drags ad relevance scores.

**Kill Action (if KILL):**
Kill SKU or rebrand listing. Escalate to TL before killing.

**Review Period Details (from PH Workbook R01):**
- Review window: 14 days
- Recovery window: 21 days from warning trigger
- Minimum click threshold before CVR is meaningful: 100 clicks
- If recovery target not reached within 21 days → escalate to TL regardless of partial improvement

---

### BL-02 — ORGANIC CVR COLLAPSE (TWO-TIER)

**Tier selection:**
- If `aov < 20` → use `_for_below_aov` thresholds
- If `aov >= 20` → use `_for_above_aov` thresholds

**Condition (WARN):**
```
IF ( (aov < 20 AND cvr < cvr_floor_warning_for_below_aov)
  OR (aov >= 20 AND cvr < cvr_floor_warning_for_above_aov) )
AND clicks >= cvr_min_clicks
AND days >= cvr_review_period_days
→ STATUS: WARN
```

**Condition (KILL):**
```
IF ( (aov < 20 AND cvr < cvr_kill_for_below_aov)
  OR (aov >= 20 AND cvr < cvr_kill_for_above_aov) )
AND clicks >= cvr_min_clicks_for_kill
AND days >= cvr_kill_period_days
→ STATUS: KILL
```

**RESTORE condition:**
```
IF ( (aov < 20 AND cvr >= cvr_recovery_target_for_below_aov)
  OR (aov >= 20 AND cvr >= cvr_recovery_target_for_above_aov) )
AND days <= cvr_recovery_window_days
→ STATUS: RECOVERED
```

**Restore Action (if WARN):**
Trigger listing audit: images, A+ content, bullets, pricing, reviews, delivery promise.

**Kill Action (if KILL):**
Kill SKU OR pause PPC immediately and escalate to TL for review.

**Review Period Details (from PH Workbook R02 — AMENDED by TL Bietrick):**
- Two-tier structure: below £20 AOV (impulse buys) vs above £20 AOV (considered purchases)
- Below £20 AOV floor: median CVR 8.33%; kill P10: 1.45%
- Above £20 AOV floor: median CVR 5.66%; kill P10: 1.80%
- Recovery targets: 10.50% (below £20) / 8.03% (above £20)
- No-improvement escalation: if recovery target not reached within 21 days → escalate to TL
- Minimum clicks before rule fires: 100 (below 100, a single non-purchase can swing CVR ±1%)

---

### BL-03 — ORGANIC IMPRESSION DECLINE

**Seasonal override (MUST CHECK FIRST):**
```
IF current month IN ('January', 'February')
AND impression_decline_pct <= 35%
→ SKIP RULE — expected seasonal movement
```
```
IF current month = 'March' AND impression_decline_pct <= 35%
AND recovery_status = 'recovering'
→ SKIP RULE — seasonal recovery in progress
```

**Condition (WARN):**
```
impression_decline_pct = (impressions_prev_30d - impressions_current_30d) / impressions_prev_30d * 100

IF impression_decline_pct > impression_decline_trigger_pct
AND NOT in seasonal override window
AND days >= impression_review_period_days
→ STATUS: WARN
```

**Condition (KILL):**
```
IF impression_decline_pct >= impression_kill_decline_pct
AND recovery not achieved within impression_kill_no_recovery_days
→ STATUS: KILL
```

**Restore Action (if WARN):**
1. Run reverse ASIN lookup — verify listing still indexed for primary search terms
2. Check for Amazon suppression or category change
3. Check for new competitor capturing ranking
4. Audit: pricing change, review drop, stock interruption

Root cause must be identified within **5 days**.
Impressions must stabilise or recover within **30 days**.

**Kill Action (if KILL):**
Relaunch SKU under new ASIN OR reset listing strategy.

**Review Period Details (from PH Workbook R03 — AMENDED by TL Bietrick):**
- Trigger raised from 25% → 30% (original 25% fired on normal Q1 seasonality)
- Jan–Feb seasonal override: up to 35% decline is normal
- Kill threshold: 50% (largest observed single-month decline was 45%)
- Recovery window: 30 days after trigger

---

### BL-04 — FBM MARGIN FLOOR BREACH

**Compute organic margin:**
```
organic_margin_pct = 1 - vat_rate_pct - cogs_pct - amazon_referral_fee_pct - (postage_cost / selling_price)
```

**Condition (WARN):**
```
IF organic_margin_pct < fbm_organic_margin_floor
AND cogs_pct = cogs_pct (confirmed applied)
AND vat_pct = vat_rate_pct (confirmed applied)
AND referral_fee_pct ≈ amazon_referral_fee_pct
AND postage_cost_applied = TRUE
→ STATUS: WARN
```

**RESTORE condition:**
```
IF organic_margin_pct >= fbm_organic_margin_floor
AND days <= margin_restore_window_days
→ STATUS: RECOVERED
```

**Condition (KILL):**
```
IF organic_margin_pct < fbm_organic_margin_floor
AND days >= margin_kill_deadline_days
AND no recovery achieved
→ STATUS: KILL
```

**Restore Action (if WARN):**
1. Review pricing: can selling price increase without losing Buy Box or organic rank?
2. Check postage: is SKU using cheapest viable carrier?
3. Review if supplier cost reduction is negotiable
4. Compare margin across PH portfolio — is this SKU an outlier?

Notify PPC team immediately to **pause paid spend** on this SKU until fixed.

**Kill Action (if KILL):**
Delist the SKU. Sub-25% organic margin = business loses money on every paid sale.

**Review Period Details (from PH Workbook R04 — VALIDATED by TL Bietrick):**
- Restore window: **7 days** (realistic for a price change on Amazon)
- Kill deadline: **14 days** (maximum acceptable exposure to sub-floor margin)
- PPC escalation: immediate — do not wait for restore window
- Economics reference: 25% floor on £24.71 AOV = £6.18 gross organic contribution before PPC

---

### BL-05 — NNV SKU DETECTION (ORGANIC)

**Compute organic contribution:**
```
organic_contribution = revenue - vat - cogs - referral_fee - postage
```

**Condition (FLAG):**
```
IF organic_contribution < 0
AND days >= nnv_consecutive_days
→ STATUS: WARN (NNV-Organic flag)
```

**Condition (INSTANT KILL):**
```
IF organic_contribution < 0
AND margin_pct < nnv_instant_kill_threshold  (e.g. margin < -10%)
→ STATUS: KILL (IMMEDIATE — no grace period)
```

**RESTORE condition:**
```
SKU must achieve positive organic margin within 14 days OR be killed.
```

**Restore Action (if WARN):**
Flag SKU as NNV-Organic. Schedule kill review with PH within `nnv_kill_review_deadline_days`.
Options: raise price, switch to cheaper postage, negotiate supplier cost, or kill.

**Kill Action (if INSTANT KILL):**
IMMEDIATE KILL. No grace period. At -10% margin, no realistic price increase fixes economics
without losing Buy Box competitiveness.

**Review Period Details (from PH Workbook R05 — VALIDATED by TL Bietrick):**
- NNV consecutive days window: 30 days (from BLOS key `nnv_consecutive_days`)
- Kill review deadline: 7 days from flag
- Grace period for recovery: 14 days (positive margin must be restored)
- Instant kill threshold: -10% margin (no grace period)
- PPC team must be notified — losses compound rapidly when PPC is added on top
- Risk flag for low-AOV PHs: Tharsiga (avg £10.94), Tharsika (avg £13.68) most exposed

---

## Step 5 — Output Format

Present results in this structure for each SKU:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SKU: [SKU_ID]  |  Channel: Amazon FBM  |  Marketplace: UK
Validated: [timestamp]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BL-01  ORGANIC CTR COLLAPSE
  Status  : [PASS / WARN / KILL / RECOVERED]
  CTR     : [actual]%  |  Floor: [blos_value]%  |  Impressions: [actual]
  Verdict : [explanation — why triggered or why passed]
  Action  : [RESTORE or KILL action text, or "No action required"]
  Next    : [Review period, deadline, escalation if applicable]

BL-02  ORGANIC CVR COLLAPSE
  Status  : [PASS / WARN / KILL / RECOVERED]
  AOV Tier: [Below £20 / Above £20]
  CVR     : [actual]%  |  Floor: [blos_value]%  |  Clicks: [actual]
  Verdict : [explanation]
  Action  : [action text]
  Next    : [Review period, deadline]

BL-03  ORGANIC IMPRESSION DECLINE
  Status  : [PASS / WARN / KILL / SEASONAL SKIP]
  Decline : [actual]%  |  Trigger: [blos_value]%
  Month   : [current month — seasonal check applied]
  Verdict : [explanation]
  Action  : [action text]
  Next    : [5-day root cause, 30-day recovery window]

BL-04  FBM MARGIN FLOOR BREACH
  Status  : [PASS / WARN / KILL / RECOVERED]
  Margin  : [actual]%  |  Floor: [blos_value]%
  Breakdown: Price £[x] | VAT [%] | COGS [%] | Referral [%] | Postage £[x]
  Verdict : [explanation]
  Action  : [action text + PPC escalation note if triggered]
  Next    : [7-day restore window, 14-day kill deadline]

BL-05  NNV ORGANIC DETECTION
  Status  : [PASS / WARN (NNV-Organic) / KILL (INSTANT)]
  Contribution: £[actual]/order  |  Days negative: [x]
  Verdict : [explanation]
  Action  : [action text]
  Next    : [Kill review in X days, 14-day grace, or IMMEDIATE KILL]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUMMARY: [X PASS | Y WARN | Z KILL]
Overall  : [GREEN / AMBER / RED]
Priority action: [Most urgent action required]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 6 — What Next (Review Period Instructions)

After showing results, always display the review period checklist for any triggered rule:

### If BL-01 WARN:
- [ ] Audit main listing image within **48 hours**
- [ ] Audit title copy within **48 hours**
- [ ] Coordinate with PPC team if ads are live on this SKU
- [ ] Re-measure CTR in **14 days**
- [ ] If CTR not recovered to target within **21 days** → escalate to TL

### If BL-02 WARN:
- [ ] Run full listing audit (images, A+, bullets, pricing, reviews, delivery promise)
- [ ] Minimum clicks check: is data statistically significant? (>100 clicks required)
- [ ] Re-measure CVR in **14 days**
- [ ] Coordinate with PPC team — pause spend if CVR is near kill threshold
- [ ] If CVR not at recovery target within **21 days** → escalate to TL

### If BL-03 WARN:
- [ ] Run reverse ASIN lookup within **48 hours**
- [ ] Check Amazon suppression status
- [ ] Check for new competitor capturing primary keyword ranking
- [ ] Root cause must be identified within **5 days**
- [ ] Impressions must stabilise within **30 days**

### If BL-04 WARN:
- [ ] Notify PPC team **immediately** to pause paid spend
- [ ] Review pricing options within **24 hours**
- [ ] Check carrier options for postage reduction
- [ ] Organic margin must be restored within **7 days**
- [ ] If not recovered in **14 days** → DELIST

### If BL-05 WARN (NNV-Organic):
- [ ] Schedule kill review with PH within **7 days** (`nnv_kill_review_deadline_days`)
- [ ] Notify PPC team immediately — advertising an NNV SKU compounds losses
- [ ] Options: raise price / cheaper postage / supplier negotiation / kill
- [ ] Positive margin must be restored within **14 days** or SKU is killed
- [ ] If margin is below `nnv_instant_kill_threshold` → **IMMEDIATE KILL, no review**

---

## Error Handling

- If BLOS key not found in database → display: `⚠ BLOS key [key_name] not found — validation skipped for [rule]. Check BLOS UI.`
- If SKU metrics not found → display: `⚠ No data found for SKU [id] in [table]. Confirm SKU exists and channel/marketplace filters are correct.`
- If impressions below `organic_ctr_min_impressions` → do not fire BL-01. Display: `BL-01: INSUFFICIENT DATA (impressions < minimum threshold)`
- If clicks below `cvr_min_clicks` → do not fire BL-02. Display: `BL-02: INSUFFICIENT DATA (clicks < minimum threshold)`

---

## Scope Notes

- This skill covers **BL-01 to BL-05 only** (organic performance + economics)
- Rules BL-06 to BL-10+ (postage, returns, reviews, dispatch, listings) are in a separate validation skill
- Channel: Amazon FBM only (this skill)
- Marketplace: UK (default); pass `marketplace` parameter for DE/FR/IT/ES
- PPC rules are owned by the Paid Campaigns team — not validated here
- All thresholds are read from BLOS at runtime — never hardcoded in this skill
