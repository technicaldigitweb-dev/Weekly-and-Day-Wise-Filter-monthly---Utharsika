# Table Definition: `public.ppc` & `public.ppc_performance`

## ⚠️ Execution Requirement
After generating any SQL against this table, **always execute it immediately using `postgres:execute_sql`** and return the real query results to the user. Never present a SQL query alone as the final answer.

---

## 🚫 CRITICAL — NEVER COMBINE eBay ON_SITE + COST_PER_SALE

> **This rule has NO exceptions. Violating it produces misleading, analytically invalid results.**

eBay Advanced (ON_SITE / CPC) and Standard (COST_PER_SALE / CPS) campaigns use **fundamentally different pricing models** — their spend, sales, and orders figures are **not comparable and must never be summed together**.

| Strategy | DB value | Charged on | Why combining is wrong |
|---|---|---|---|
| Advanced / CPC | `ON_SITE` | Per click — fixed cost regardless of sale | Spend is independent of sales |
| Standard / CPS | `COST_PER_SALE` | % of sale — only when a sale occurs | Spend is mechanically tied to sales |

### The rule in practice

- **"Show me eBay spend"** → return TWO rows: one for Advanced, one for Standard. Never one combined row.
- **"Show me total eBay performance"** → still split by strategy. Add a note explaining why.
- **"Can you combine them?"** → return both separately and explain the combination is invalid.
- **Cross-platform tables** (Amazon vs eBay vs Google) → eBay must appear as two rows, not one.

### ❌ ALWAYS WRONG
```sql
-- DO NOT DO THIS — mixes incompatible metric definitions
SELECT SUM(pp.spend), SUM(pp.sales)
FROM public.ppc_performance pp
WHERE pp.source = 2;
```

### ✅ ALWAYS RIGHT
```sql
SELECT
    CASE p.record_subtype
        WHEN 'ON_SITE'       THEN 'Advanced (CPC)'
        WHEN 'COST_PER_SALE' THEN 'Standard (CPS)'
        ELSE p.record_subtype
    END AS strategy,
    SUM(pp.impressions) AS impressions,
    SUM(pp.clicks)      AS clicks,
    SUM(pp.spend)       AS spend,
    SUM(pp.sales)       AS sales,
    SUM(pp.orders)      AS orders,
    SUM(pp.spend) / NULLIF(SUM(pp.sales), 0) * 100 AS acos,
    SUM(pp.sales) / NULLIF(SUM(pp.spend), 0)        AS roas
FROM public.ppc p
JOIN public.ppc_performance pp ON p.parent_id = pp.parent_id
WHERE pp.source = 2
  AND p.record_main_type = 'campaign'
  AND pp.record_type = 'campaign'
GROUP BY p.record_subtype;
```

---

## Overview

Two tables form the core of the PPC ETL data model:

| Table | Role |
|-------|------|
| `public.ppc` | Metadata / dimension store — one row per PPC entity (campaign, ad group, asset group, asset) |
| `public.ppc_performance` | Fact store — one date-grain row per performance event |

They share **no FK constraint** but are logically joined via  `parent_id`, and `child_id`.

---

## Table 1: `public.ppc` (Metadata / Dimension)

### Columns

| Column | Type | Description |
|--------|------|-------------|
| `ppc_etl_id` | BIGINT UNSIGNED | Primary key |
| `parent_id` | VARCHAR(255) | Parent entity ID — meaning shifts with `record_main_type` and source (see mapping below) |
| `child_id` | VARCHAR(255) | Child entity ID — '0' for top-level (campaign) rows |
| `record_main_type` | VARCHAR(15) | Entity grain: `campaign`, `ad_group`, `asset_group`, `asset` |
| `record_subtype` | VARCHAR(30) | Campaign/entity sub-type (e.g. SP, SD, SB, SEARCH, SHOPPING, asset type) |
| `record_name` | VARCHAR(255) | Display name of the entity |
| `record_status` | VARCHAR(20) | Normalised lifecycle state (`active`, `paused`, `archived`, etc.) |
| `bidding_strategy` | VARCHAR(10) | Targeting/bidding indicator — Amazon: `Auto`/`Manual`; |


### This is `public.ppc` data integrity ways

| Entity | `record_main_type` | `parent_id` | `child_id` | `record_status` examples | `record_subtype` examples | `bidding_strategy` |
|--------|--------------------|-------------|------------|--------------------------|---------------------------|--------------------|
| Amazon campaign | `campaign` | Campaign ID | '0' | paused, archive, active | SP / SD / SB | Auto / Manual |
| Amazon ad group | `ad_group` | Campaign ID | AdGroup ID | paused, archive, active | '0' | '0' |
| eBay campaign | `campaign` | Campaign ID | '0' | running, paused, ended, deleted | ON_SITE, COST_PER_SALE, OFF_SITE | MANUAL, SMART |
| eBay ad group | `ad_group` | Campaign ID | AdGroup ID | paused, ended, active, archived | '0' | '0' |
| Google campaign | `campaign` | Campaign ID | '0' | active, paused, removed | PERFORMANCE_MAX, SHOPPING, SEARCH, DISPLAY, etc. | MAXIMIZE_C, MANUAL_CPC, TARGET_ROA, TARGET_CPA, etc. |
| Google ad group | `ad_group` | Campaign ID | AdGroup ID | active, paused, removed | '0' | '0' |
| Google asset group | `asset_group` | Campaign ID | asset_group_id | enabled, paused, removed | '0' | '0' |
| Google asset | `asset` | asset_group_id | asset_id | '0' | LOGO, HEADLINE, YOUTUBE_VIDEO, DESCRIPTION, etc. | '0' |

---

## Table 2: `public.ppc_performance` (Fact / Performance)

### Columns

| Column | Type | Description                                                               |
|--------|------|---------------------------------------------------------------------------|
| `performance_data_id` | BIGINT UNSIGNED | Primary key                                                               |
| `date` | DATE | Performance date                                                          |
| `source` | TINYINT UNSIGNED | 1=Amazon, 2=eBay, 3=Google Ads or it will consider as shopify             |
| `source_name` | VARCHAR | Human-readable source label                                               |
| `marketplace_id` | TINYINT UNSIGNED | Marketplace identifier                                                    |
| `marketplace` | VARCHAR | Marketplace name                                                          |
| `sub_source_id` | TINYINT UNSIGNED | Sub-source / account identifier                                           |
| `ss_name` | VARCHAR | Sub-source name                                                           |
| `ref_id` | VARCHAR(100) | External product/listing reference (ASIN, item_id) — may be '0'           |
| `sku` | VARCHAR(100) | SKU — Amazon only; '0' for others                                         |
| `record_type` | VARCHAR(15) | Fact grain: `ad`, `product`, `asset`, `campaign`                          |
| `record_id` | VARCHAR(100) | Entity ID at the fact grain (ad id, product_item_id, asset_id, campaign_id) |
| `parent_id` | VARCHAR(100) | Campaign ID (or asset_group_id for asset rows)                            |
| `child_id` | VARCHAR(100) | Ad group ID — '0' when not applicable                                     |
| `impressions` | INT UNSIGNED | Impressions count                                                         |
| `clicks` | INT UNSIGNED | Clicks count                                                              |
| `sales` | DECIMAL(10,2) | Attributed revenue / conversion value                                     |
| `orders` | DECIMAL(10,2) | Attributed orders / conversions                                           |
| `spend` | DECIMAL(10,2) | Advertising cost                                                          |
| `category_name` | VARCHAR | Category label                                                            |
| `user_name` | VARCHAR | User/account label                                                        |

### This is `public.ppc_performance` data integrity ways

| Source | `record_type` | `ref_id` | `sku` | `record_id` | `child_id` | `parent_id` |
|--------|---------------|----------|-------|-------------|------------|-------------|
| Amazon | `ad`          | ASIN     | SKU | amzAdId | AdGroup ID | Campaign ID |
| eBay | `campaign`    | '0'       | '0' | Campaign ID | '0' | Campaign ID |
| eBay | `ad`    |  item_id      | '0' | ebayAdId | AdGroup ID | Campaign ID |
| Google campaign-level | `campaign`    | '0'      | '0' | Campaign ID | '0' | Campaign ID |
| Google PMAX asset | `asset`       |  '0'     | '0' | Asset ID | '0' | Asset Group ID |
| Google Shopping Ads | `product`     | Parent ID      | Variation ID | Product Item Id | '0' | Campaign ID |



---
## SQL Generation Rules

### ROUND() is forbidden — cast to numeric instead

PostgreSQL has no `ROUND(double precision, integer)` overload. Even though `spend` and `sales` are `numeric`, arithmetic chains involving `NULLIF()` and multiplication can promote the result to `double precision`, breaking `ROUND()`.

```sql
-- ❌ NEVER — will error if result is promoted to double precision
ROUND(SUM(pp.spend) / NULLIF(SUM(pp.sales), 0) * 100, 2)

-- ✅ ALWAYS — cast to numeric before any rounding or truncation
(SUM(pp.spend) / NULLIF(SUM(pp.sales), 0) * 100)::numeric

-- ✅ If decimal places are needed, use TRUNC after casting
TRUNC((SUM(pp.spend) / NULLIF(SUM(pp.sales), 0) * 100)::numeric, 2)
```

## SB (Sponsored Brands) Campaign — Include vs Exclude Rule

**Why SB is special:** Amazon does not provide ad-level data for SB campaigns. Only one ASIN gets mapped to the SB campaign in the DB, but the campaign actually covers multiple ASINs. This means SB spend/sales cannot be accurately attributed to any specific ASIN or SKU — the mapped ASIN is not representative.

**Exclude SB** (`AND p.record_subtype != 'SB'`) when the user mentions a specific ASIN or SKU value in their question — filtering by a specific ASIN/SKU against SB data returns misleading numbers because the mapped ASIN does not reflect all products in the campaign.

**Include SB** (no filter needed) for all other Amazon questions — totals, campaign-wise, sub-source, marketplace, date range, or any question that is not scoped to a specific ASIN or SKU value.

| User question | SB included? |
|---------------|-------------|
| "ledsone uk amazon total metrics last 30 days" | ✅ Yes |
| "amazon UK campaign wise spend" | ✅ Yes |
| "dcv amazon performance this month" | ✅ Yes |
| "spend for ASIN B08V5MK449" | ❌ No — specific ASIN mentioned |
| "campaign wise for B08V5MK449" | ❌ No — specific ASIN mentioned |
| "top SKUs by spend" | ❌ No — SKU-level question |

---

## Joining the Two Tables

### Campaign-level join (with required GROUP BY)

```sql
-- Amazon: campaign totals (aggregating ad-grain rows)
SELECT p.record_name AS campaign_name,
       p.record_subtype, p.record_status, p.bidding_strategy,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales,
       SUM(pp.orders)      AS orders
FROM public.ppc p
JOIN public.ppc_performance pp 
  ON p.parent_id = pp.parent_id   AND p.record_main_type = 'campaign'
  AND pp.record_type = 'ad';
WHERE pp.source = 1


-- eBay: campaign totals (always include record_subtype for Advanced/Standard distinction)
SELECT p.record_name, 
       p.record_subtype,                  -- ON_SITE = Advanced, COST_PER_SALE = Standard
       p.record_status,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales,
       SUM(pp.orders)      AS orders
FROM public.ppc p
JOIN public.ppc_performance pp 
  ON p.parent_id = pp.parent_id   AND p.record_main_type = 'campaign'
  AND pp.record_type = 'campaign';
WHERE pp.source = 2


-- Google Ads: campaign totals
SELECT p.record_name, p.record_subtype, p.record_status, p.bidding_strategy,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales,
       SUM(pp.orders)      AS orders
FROM public.ppc p
JOIN public.ppc_performance pp 
  ON p.parent_id = pp.parent_id   AND p.record_main_type = 'campaign'
  AND pp.record_type = 'campaign';
WHERE pp.source = 3

```

### Ad-group-level join

`public.ppc.child_id` (AdGroup ID) ↔ `public.ppc_performance.child_id`

```sql
-- Amazon: ad group totals
SELECT p.record_name AS ad_group_name, p.record_status,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales
FROM public.ppc p
JOIN public.ppc_performance pp ON p.child_id = pp.child_id
  AND p.record_main_type = 'ad_group'
  AND pp.record_type = 'ad';
WHERE pp.source = 1

```

```sql
-- Ebay: enrich ad performance with ad group metadata
SELECT p.record_name AS ad_group_name, p.record_status, pp.*
FROM public.ppc p
JOIN public.ppc_performance pp ON p.child_id = pp.child_id
AND p.record_main_type = 'ad_group'
  AND pp.record_type     = 'ad'
WHERE pp.source=2
```

### Asset-group-level join (Google PMAX only)

`public.ppc.child_id` (Asset Group ID) ↔ `public.ppc_performance.parent_id`

```sql
-- Google PMAX: asset group totals
SELECT p.record_name AS asset_group_name, p.record_status,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales
FROM public.ppc p
JOIN public.ppc_performance pp 
  ON p.child_id = pp.parent_id
WHERE pp.source = 3
  AND p.record_main_type = 'asset_group'
  AND pp.record_type = 'asset';
```

### Asset-level join (Google PMAX only)

```sql
-- Google PMAX: asset totals
SELECT p.record_name AS asset_value,
       p.record_subtype AS asset_type,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales
FROM public.ppc p
JOIN public.ppc_performance pp 
  ON p.parent_id = pp.parent_id
  AND p.child_id = pp.record_id
WHERE pp.source = 3
  AND p.record_main_type = 'asset'
  AND pp.record_type = 'asset';
```

### Product-level join (Google Shopping/Search only)

`public.ppc.parent_id` (Campaign ID) ↔ `public.ppc_performance.parent_id`
Product details live only in `public.ppc_performance` — `ref_id` (parent_id of that product), `sku` (variation_id), `record_id` (product_item_id).

> ⚠️ Google product rows have **no matching metadata row** in `public.ppc` at the product grain. Join goes through the **campaign** record in `ppc` to get campaign name/status, then product fields come straight from `ppc_performance`.

```sql
-- Google Shopping/Search: product-level performance with parent campaign metadata
SELECT p.record_name AS campaign_name,
       p.record_subtype AS campaign_type,
       p.record_status,
       pp.ref_id AS product_parent_id,
       pp.sku AS variation_id,
       pp.record_id AS product_item_id,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales,
       SUM(pp.orders)      AS orders
FROM public.ppc p
JOIN public.ppc_performance pp 
  ON p.parent_id = pp.parent_id   AND p.record_main_type = 'campaign'
  AND pp.record_type = 'product';
WHERE pp.source = 3

```

---

## ⚠️ Cross-Platform Granularity Mismatch — Ask Before Querying

The three platforms expose **different fact grains** in `public.ppc_performance`. When a user asks for cross-platform comparison using a generic term (like "ads", "performance", "spend"), the term does NOT map cleanly across platforms. Claude MUST ask a clarifying question before generating SQL.

### Available Grains by Platform

| Platform | Available `record_type` values | Notes |
|----------|-------------------------------|-------|
| Amazon (source=1) | `ad` | Only ad-grain available |
| eBay (source=2) | `campaign`, `ad` | `ad` exists only for `COST_PER_SALE` strategy; `ON_SITE` has campaign-grain only |
| Google/Shopify (source=3) | `campaign`, `product`, `asset` | Different grains for Search/Shopping vs PMAX |

### Trigger Words That Require Clarification

If a user asks for any of these across multiple platforms, **STOP and ask** before writing SQL:

- **"ads"** → Amazon has ads; eBay only for CPS campaigns; Google has no `ad` grain at all (has products/assets instead)
- **"products"** → Only Google has product-grain; Amazon's product info is on the `ad` row via `ref_id`/`sku`; eBay has `ebayListingId` on the `ad` row
- **"performance"** / **"data"** / **"results"** → too generic; ask which grain
- **"campaigns"** → safe-ish (all three have campaign-grain), but eBay needs strategy split (see eBay rule)
- **"all platforms" / "compare all" / "across channels"** → always confirm grain choice

### Required Clarification Pattern

When ambiguity exists, Claude should respond with a short question listing the realistic options, **not** guess. Example:

> User: "Show me ads performance across Amazon, eBay, and Google for the last 30 days."
>
> Claude: "Before I run this — the platforms don't share the same 'ad' grain:
> - **Amazon** has ad-level data (per ASIN/SKU)
> - **eBay** has ad-level data only for Standard/CPS campaigns; Advanced/CPC campaigns are campaign-grain only
> - **Google** has no ad grain — it has product-grain (Shopping/Search) and asset-grain (PMAX)
>
> How would you like me to compare?
> 1. **Campaign-level totals** across all three (most apples-to-apples)
> 2. **Best available grain per platform** (Amazon: ads, eBay: split by strategy, Google: products)
> 3. **Custom mapping** — tell me which grain you want for each"

### When NOT to Ask

Skip the clarification step when:
1. The user names the grain explicitly ("campaign-level", "by product", "ad-by-ad")
2. The user names only one platform — use that platform's natural grain
3. The user asks for "total spend/sales" cross-platform — default to campaign-grain and state the assumption inline



## ⚠️ eBay Campaign Type Translation Rule (CRITICAL — prevents hallucination)

Users describe eBay campaigns in **business terminology**, but the database stores **raw eBay API values**. You MUST translate user terms before querying.

### Terminology Mapping

| User says (any of these) | Actual DB value (`record_subtype`) | What it is |
|--------------------------|------------------------------------|------------|
| **Advanced** / **Priority** / **CPC** / **Cost Per Click** / **priority strategy** / **on-site** | `ON_SITE` | eBay's premium ad placement, charged per click |
| **Standard** / **General** / **CPS** / **Cost Per Sale** / **general strategy** | `COST_PER_SALE` | eBay's basic promoted listing, charged on attributed sale |
| **Off-site** / **External** | `OFF_SITE` | eBay external traffic ads |

### Translation Rules for eBay Queries

1. **Always filter by `record_subtype`** when the user mentions any of the above terms.
2. **Always join `public.ppc` to read `record_subtype`** — `public.ppc_performance` does not store campaign type.
3. The user's word is NOT a search term — do not use `record_name LIKE '%advanced%'`. Use `p.record_subtype = 'ON_SITE'`.



### Example Queries with Terminology Translation

#### "Show me advanced campaign performance" → ON_SITE
```sql
SELECT p.record_name AS campaign_name,
       p.record_subtype AS campaign_type,
       p.record_status,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales,
       SUM(pp.orders)      AS units_sold
FROM public.ppc p
JOIN public.ppc_performance pp ON p.parent_id = pp.parent_id
WHERE pp.source = 2
  AND p.record_main_type = 'campaign'
  AND pp.record_type = 'campaign'
  AND p.record_subtype = 'ON_SITE' ;         -- ← "advanced" / "priority" / "CPC"
```


#### "Show me standard campaign performance" → COST_PER_SALE
```sql
SELECT p.record_name AS campaign_name,
       p.record_subtype AS campaign_type,
       p.record_status,
       SUM(pp.impressions) AS impressions,
       SUM(pp.clicks)      AS clicks,
       SUM(pp.spend)       AS spend,
       SUM(pp.sales)       AS sales,
       SUM(pp.orders)      AS units_sold
FROM public.ppc p
JOIN public.ppc_performance pp ON p.parent_id = pp.parent_id
WHERE pp.source = 2
  AND p.record_main_type = 'campaign'
  AND pp.record_type = 'campaign'
  AND p.record_subtype = 'COST_PER_SALE' ;    -- ← "standard" / "general" / "CPS"
```

### 🚫 CRITICAL — Never Sum ON_SITE + COST_PER_SALE Together (see top of file for full rule)

eBay's two campaign strategies (`ON_SITE` / Advanced and `COST_PER_SALE` / Standard) come from **different upstream tables with different metric definitions**. **Do NOT sum them into a single eBay total — ever, under any circumstances.**

**Rules:**
1. When the user asks for "total eBay spend/sales/orders", **always break it out by `record_subtype`** — return two rows (Advanced and Standard), not one combined number.
2. If the user explicitly asks for one combined number, **still return both separately** and explain why combining is analytically invalid.
3. Cross-platform totals (Amazon vs eBay vs Google) must keep eBay split into two rows — eBay never collapses to a single row.


---

## ⚠️ "Metrics" Keyword Expansion Rule

When a user asks for **"metrics"**, **"all metrics"**, **"full metrics"**, **"KPIs"**, or **"performance metrics"**, Claude MUST return the complete metric set below — not a subset, and not just spend/sales.

### Required Metric Set

| Metric | Source | Formula |
|--------|--------|---------|
| `impressions` | `pp.impressions` | `SUM(pp.impressions)` |
| `clicks` | `pp.clicks` | `SUM(pp.clicks)` |
| `spend` | `pp.spend` | `SUM(pp.spend)` |
| `sales` | `pp.sales` | `SUM(pp.sales)` |
| `orders` | `pp.orders` | `SUM(pp.orders)` |
| `acos` | derived | `spend / sales × 100` (Advertising Cost of Sale, %) |
| `roas` | derived | `sales / spend` (Return on Ad Spend, multiplier) |

### When NOT to Apply This Rule

Skip the expansion when the user names specific metrics:
- "Show me spend and sales" → return only spend and sales (and currency context)
- "Just impressions please" → return only impressions
- "What's the ROAS?" → return only ROAS (with sales/spend for context)
--- 

## Source Reference (lives only in `public.ppc_performance`)

| `source` | Platform   | `source_name` |
|----------|------------|---------------|
| 1        | Amazon     | AMAZON        |
| 2        | eBay       | EBAY          |
| 3        | Google Ads | SHOPIFY (legacy label — actually means Google Ads) |

---

## Reference Lists

**Platforms (`source_name`):** AMAZON, EBAY, SHOPIFY (SHOPIFY mens Google Ads)

**Sub-Sources (`ss_name`) by Platform:**

- **AMAZON:** amazon Dcvoltage, amazon Ledsone, amazon SRM Amazon, Neighbour Market

- **EBAY:** electricalsone, huettenlampen, led_sone, ledsonede, so_926407

- **SHOPIFY:** 045e77-2, electricalsoneuk, jedsz8-km, ledsone, ledsone-de, ledsone-us, vintage-light-web

**Marketplaces (`marketplace`):** Austria, Belgium, Belgium_Dutch, Belgium_French, Canada, France, Germany, Ireland, Italy, Mexico, Netherlands, Poland, Saudi Arabia, Spain, Sweden, Switzerland, UK, United Arab Emirates, US

**Categories:** Artificial Flowers, Batton Aluminium lighting, Belts, Cable tie, Cables, Ceiling light - Cone Shade Set, Ceiling light - Wide Shade Set, Ceiling light Curvy set, Ceiling light Dome shade set, Ceiling light Flat shade, Ceiling roses, Chains, Clip boards, Clocks, Conduit lighting, Connector, Crystal Glass Lamp Shades, Fabric Shades, Gift Bags, Glass Lamp Shades, Hemp set, Holder Rings, Injection module & C, Lamp holders, Laundry Bag, LED Bulbs, Mail Bag, Metal Lamp Shades, Mortar and pestle, Mosque and Tear Drop shades, Panel Lights, Peel and stick, Pendant lights, Pipe Lightings, Plug in Pendants, Reducer Plates, Shade Rings, Spare parts, Spot Lights, Storage Bag, Table Lamps, Tapes, Thread rods, Tile's spare parts, Transformer, Wall lamps, Wall Plugs, Screws, Water proof Junction box, White boards, Wire Cages

**Users:** Abinayaa, anoja, Arudchelvi, Dilani, Illakkiya, Jasmini, Jubista, kobitharsan, mothajini, Nithushana, paulr, Poovitha, prasath, preethi, Renuha, Saranya, Shanthini, shimee, thanucha, thanusha, Tharshana, Tharsiga(nelli), Tharsika(jaffna), Theepana, Thojika, thuwaraga, utharsika