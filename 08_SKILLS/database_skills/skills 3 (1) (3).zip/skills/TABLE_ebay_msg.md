# Table Definition: `message.ebay_msg`

## ⚠️ Execution Requirement
After generating any SQL against this table, **always execute it immediately using `postgres:execute_sql`** and return the real query results to the user. Never present a SQL query alone as the final answer.

---

## Purpose
Pre-built eBay customer support message table. Each row is one complete eBay message — header metadata (buyer, listing, folder, read/reply flags, dates) joined with the message body text and the store account name. Built by the ETL pipeline from `messages_headers` + `ebay_messages` + `sub_source`. Use this table for all eBay message queries — query it directly, no joins to source tables needed.

---

## Schema

| Column | Type | Description |
|--------|------|-------------|
| `id` | bigint | Primary key |
| `message_id` | text | eBay message id string — sync upsert key |
| `ext_message_id` | double precision | eBay external message id |
| `sender_id` | text | Buyer eBay user id (inbox rows); seller sub_source id (sent rows) |
| `receiver_id` | text | Counterparty on sent rows (buyer id when folder is sent) |
| `sub_source` | bigint | eBay account numeric id |
| `ss_name` | text | eBay store account name (e.g. `electricalsone`, `led_sone`) |
| `item_id` | double precision | eBay listing id — thread key with `sender_id`; not an order id |
| `message_type` | text | eBay message type from API sync |
| `subject` | text | Subject — JSON-encoded from eBay API; decode for plain-text display |
| `read_status` | bigint | `1` = Read, `2` = Unread |
| `flagged` | bigint | `1` = Flagged, `2` = Not flagged |
| `reply_status` | bigint | `1` = Replied, `0` = Not replied yet |
| `no_reply` | bigint | `1` = No reply needed, `0` = Reply expected/required |
| `folder_id` | bigint | `0` = Inbox, `1` = Sent |
| `msg_sync_status` | bigint | `0` = Body pending, `1` = Body synced |
| `root_cause` | text | Root cause label — mostly NULL, populated manually |
| `response_date` | timestamp | Last response timestamp (used for list sorting) |
| `receive_date` | timestamp | Received timestamp |
| `message_content` | text | Message body text — JSON-encoded from eBay sync; NULL if body not yet synced |

---

## Key Business Rules

- **eBay channel only** — all rows are eBay messages; `ss_name` is always an eBay store name
- **One row = one eBay message** — threads group by `item_id` + `sender_id`
- **Inbox filter** — `folder_id = 0`, `sender_id != 'eBay'`, `ext_message_id IS NOT NULL`
- **Reply queue** — `reply_status = 0` AND `no_reply = 0` = messages still needing a reply
- **No reply needed** — `no_reply = 1` excludes thank-you, acknowledgment, or conversation-ending messages; exclude from reply queues
- **Body pending** — `message_content` is NULL when `msg_sync_status = 0`; do not treat a NULL body as an error
- **Subject and body encoding** — both `subject` and `message_content` are JSON-encoded from the eBay API; decode for plain-text display
- **Thread sort** — `ORDER BY COALESCE(response_date, receive_date) DESC, id DESC`
- **Store filter** — use `ss_name` for human-readable store filtering (e.g. `WHERE ss_name = 'electricalsone'`)
- **No `order_id` column** — order ids come via `customer_info` + `order_item_info` bridged on `sender_id` + `item_id`

---

## Common Query Patterns

### Inbox messages requiring a reply
```sql
SELECT id, sender_id, item_id, ss_name, subject,
       receive_date, reply_status, no_reply, message_content
FROM message.ebay_msg
WHERE folder_id = 0
  AND sender_id != 'eBay'
  AND ext_message_id IS NOT NULL
  AND reply_status = 0
  AND no_reply = 0
ORDER BY COALESCE(response_date, receive_date) ASC;
```

### Full message by id
```sql
SELECT id, sender_id, receiver_id, item_id, ss_name,
       subject, message_type, folder_id, read_status,
       reply_status, no_reply, receive_date, response_date,
       root_cause, message_content
FROM message.ebay_msg
WHERE id = :message_id;
```

### Thread by buyer and listing
```sql
SELECT id, sender_id, receiver_id, message_type, subject,
       receive_date, response_date, reply_status, no_reply, message_content
FROM message.ebay_msg
WHERE item_id = :item_id
  AND (sender_id = :buyer OR receiver_id = :buyer)
ORDER BY COALESCE(response_date, receive_date) DESC, id DESC
LIMIT 12;
```

### Messages pending body sync
```sql
SELECT id, ext_message_id, sub_source, ss_name
FROM message.ebay_msg
WHERE msg_sync_status = 0
  AND ext_message_id IS NOT NULL
LIMIT 100;
```

### Messages by store account
```sql
SELECT id, sender_id, item_id, subject,
       receive_date, reply_status, no_reply, message_content
FROM message.ebay_msg
WHERE ss_name = 'electricalsone'
  AND folder_id = 0
ORDER BY COALESCE(response_date, receive_date) DESC;
```

### Unread inbox messages
```sql
SELECT id, sender_id, item_id, ss_name,
       subject, receive_date, message_content
FROM message.ebay_msg
WHERE folder_id = 0
  AND read_status = 2
ORDER BY receive_date DESC;
```

### Related order IDs for a message thread
```sql
SELECT DISTINCT o.order_id
FROM message.ebay_msg em
INNER JOIN customer_info ci ON ci.ci_ebay_buyer_id = em.sender_id
INNER JOIN "order" o ON o.order = ci.ci_order_id
INNER JOIN order_item_info oii
    ON oii.oii_order_ref_id = o.order
    AND oii.oii_item_id = em.item_id
WHERE em.item_id = :item_id
  AND em.sender_id = :buyer;
```

---

## Bridge to Other Tables

| Target Table | Join Key | Notes |
|---|---|---|
| `sub_source` | `ebay_msg.sub_source = sub_source.sub_source` | eBay store account details (`ss_source = 2`) |
| `ebay_products` | `ebay_msg.item_id = ebay_products.item_id` | Listing / SKU for the thread |
| `customer_info` | `ebay_msg.sender_id = customer_info.ci_ebay_buyer_id` | Buyer rows; one row per order via `ci_order_id` |
| `order` | `customer_info.ci_order_id = order.order` | Marketplace order id in `order.order_id` |
| `order_item_info` | `oii.oii_order_ref_id = order.order` and `oii.oii_item_id = ebay_msg.item_id` | Listing line match for related orders |
| `messages_auto_tags` | `sender_id`, `item_id`, `ext_message_id` | Auto-tags on message threads |
| `message_templates` | `ref_id = ext_message_id`, `channel = 'ebay'` | Saved reply templates |
| `repeated_messages` | `ref_id` + `source = 'ebay'` | Repeat-message detection |

---

## Reference Lists

**Folder (`folder_id`):** `0` = Inbox, `1` = Sent

**Read Status (`read_status`):** `1` = Read, `2` = Unread

**Flagged (`flagged`):** `1` = Flagged, `2` = Not flagged

**Reply Sent (`reply_status`):** `0` = Not replied yet, `1` = Replied

**Reply Needed (`no_reply`):** `0` = Reply expected / needed, `1` = No reply needed (conversation-ending or similar)

**Body Sync (`msg_sync_status`):** `0` = Pending (`message_content` NULL), `1` = Synced

**Store Accounts (`ss_name`):** led_sone, re6865, bestbringer, so_926407, dctransformer, electricalsone, lighting_sone, coventrylights, electro_shine, uk-lightsway, ledsonede, huettenlampen, vintageinterior, electbout0, koneswaransrikanesh, nanthinvasude-0, ur26574, cottagelighting, homin_gmbh, longtek020, ledpedia, neighbourmarket
