# Table Definition: `public.thresholds`

## ⚠️ Execution Requirement
After generating any SQL against this table, **always execute it immediately using `postgres:execute_sql`** and return the real query results to the user. Never present a SQL query alone as the final answer.

---

## Purpose
Runtime configuration store for all FBM Portfolio Holder business rules (BL-01 to BL-32, BL-E01 to BL-E24, BL-G01 to BL-G14).

Each row is a single named threshold value belonging to a rule. This table is the **live source of truth** for all rule validators — threshold values are always read from here at runtime, never hardcoded.

---

## Schema — Necessary Columns Only

| Column | Type | Description |
|--------|------|-------------|
| `rule_id` | text | Rule identifier — e.g. `BL-01`, `BL-E03`, `BL-G07` |
| `threshold_key` | text | BLOS key name — the exact name validators use to look up values (e.g. `organic_ctr_floor_warning`) |
| `value` | double precision | The threshold value — the actual number used in rule condition checks |
| `value_type` | text | How to interpret the value: `percentage`, `numeric`, `currency` |
| `unit` | text | Unit of the value: `%`, `days`, `clicks`, `impressions`, `£`, `stars`, `x`, `orders`, `hours` |
| `direction` | text | How the value is applied: `below` (fail if metric goes below), `above` (fail if metric exceeds), `decline` (fail if % drop exceeds), `duration` (time window), `within` (tolerance band), `fixed` (constant used in formulas) |
| `domain` | text | Business domain this rule belongs to (see Domain Reference below) |
| `status` | text | `active` = live and enforced; `inactive` = disabled. **Always filter `WHERE status = 'active'`** |

---

## How to Fetch Thresholds for a Rule

### Fetch all keys for one rule
```sql
SELECT threshold_key, value, unit, direction
FROM public.thresholds
WHERE rule_id = 'BL-01'
  AND status = 'active';
```

### Fetch a single specific key
```sql
SELECT value
FROM public.thresholds
WHERE rule_id = 'BL-01'
  AND threshold_key = 'organic_ctr_floor_warning'
  AND status = 'active';
```

### Fetch all keys for multiple rules at once
```sql
SELECT rule_id, threshold_key, value, unit, direction
FROM public.thresholds
WHERE rule_id IN ('BL-01', 'BL-02', 'BL-03', 'BL-04', 'BL-05')
  AND status = 'active'
ORDER BY rule_id, threshold_key;
```

### Fetch all rules in a domain
```sql
SELECT rule_id, threshold_key, value, unit, direction
FROM public.thresholds
WHERE domain = 'Organic Listing Performance'
  AND status = 'active'
ORDER BY rule_id, threshold_key;
```

---

## Rule ID Series Reference

| Series | Platform / Scope | Rule Range |
|--------|-----------------|------------|
| `BL-01` to `BL-32` | Amazon FBM — organic performance, economics, PPC, lifecycle | 32 rules |
| `BL-E01` to `BL-E24` | eBay — organic performance, economics, PPC | 24 rules |
| `BL-G01` to `BL-G14` | Google Ads — PPC performance | 14 rules |

---

## Domain Reference

| `domain` | Rules | What it covers |
|----------|-------|----------------|
| `Amazon Organic Listing Performance` | BL-01 | CTR monitoring |
| `Organic Listing Performance` | BL-02, BL-03 | CVR, impression decline |
| `Product Economics` | BL-04, BL-05, BL-06 | Margin floor, NNV, postage ceilings |
| `Product Quality` | BL-07, BL-08 | Refund rate, ratings |
| `Fulfilment SLA` | BL-09, BL-10 | Late dispatch, damage rate |
| `SKU Lifecycle` | BL-11, BL-12 | New SKU revenue, listing content standards |
| `Portfolio Health` | BL-13, BL-14 | AOV decline, revenue concentration |
| `Pricing Strategy` | BL-15, BL-16 | Competitor undercutting, channel parity |
| `Amazon PPC Performance` | BL-17 to BL-22 | ACoS (SP/SB/SD), ROAS, CVR drop, CTR floor |
| `Amazon PPC Spend` | BL-23 to BL-26 | Daily spend cap, acceleration, wasted spend |
| `PPC Inventory` | BL-27 | Stock days remaining |
| `PPC Returns` | BL-28, BL-29 | Return rate, return spike |
| `PPC Margin` | BL-30 | Net margin floor |
| `PPC Governance` | BL-31, BL-32 | Unapproved campaigns, budget changes |

---

## `direction` Values — How to Use Them in Conditions

| `direction` | Meaning | Example condition |
|-------------|---------|-------------------|
| `below` | Trigger if metric < value | `IF ctr < organic_ctr_floor_warning → WARN` |
| `above` | Trigger if metric > value | `IF spend > max_daily_spend_critical_limit → KILL` |
| `decline` | Trigger if % drop > value | `IF decline_pct > impression_decline_trigger_pct → WARN` |
| `duration` | Time window — not a trigger condition, used as a period parameter | `review last N days` |
| `fixed` | Constant used in a formula — not a trigger | `margin = 1 - vat_rate_pct - cogs_pct - ...` |
| `within` | Trigger if metric is within ±value of a reference | `IF price within 5% of competitor → parity flag` |

---

## `value_type` Values

| `value_type` | How to interpret `value` |
|---|---|
| `percentage` | Divide by 100 when computing, or compare directly to a `%` metric |
| `numeric` | Raw count — impressions, clicks, orders, days, stars |
| `currency` | Monetary amount in £ (GBP is the base currency) |

---

## Critical Usage Rules

1. **Always filter `WHERE status = 'active'`** — inactive rows must never be used in validation.
2. **Never hardcode threshold values** — always fetch from this table at runtime via `postgres:execute_sql`.
3. **`threshold_key` is the lookup identifier** — this is the BLOS key name that validator skills use. Match exactly (case-sensitive).
4. **One row = one threshold** — a single rule has multiple rows (one per threshold key). Fetch all keys for a rule in a single query.
5. **`value` can be NULL** — some warning-level thresholds are not yet configured (only critical thresholds are set). Always check for NULL before applying in a condition; skip the condition if value is NULL.

---

## NULL Value Handling

Some thresholds have `value = NULL` — these are warning thresholds not yet defined. Handle safely:

```sql
-- Always check for NULL before applying threshold in application logic
SELECT threshold_key, value
FROM public.thresholds
WHERE rule_id = 'BL-24'
  AND status = 'active';
-- If value IS NULL → skip that condition, do not error
```
