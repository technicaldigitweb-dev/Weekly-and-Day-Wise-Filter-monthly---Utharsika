# Table Definitions: `development.user_answers` & `development.answer_comparisons`

## ⚠️ Execution Requirement
After generating any SQL against these tables, **always execute it immediately using `postgres:execute_sql`** and return the real query results to the user. Never present a SQL query alone as the final answer.

---

## Table 1: `development.user_answers`

### Purpose
Stores the SQL query results for every user × question pair after each daily run. One row per user per question per run date.

### Schema

| Column | Type | Description |
|---|---|---|
| `id` | serial | Auto-increment primary key |
| `run_date` | date | Date the run was executed. Format: `YYYY-MM-DD` |
| `answered_at` | timestamp | Exact datetime the answer was written |
| `user_name` | varchar(200) | The seller/user the SQL was executed for |
| `question_no` | integer | Question number |
| `question` | text | Full question text |
| `category` | varchar(200) | Category name (e.g. `Sales`, `PPC`, `Inventory`) |
| `answer_type` | varchar(50) | Rendering type. Valid values: `SUMMARY_CARD`, `RANKED_TABLE`, `FLAG_TABLE`, `OPPORTUNITY_LIST`, `PLATFORM_BREAKDOWN`, `CONCENTRATION_CHECK`, `YOY_CHECK` |
| `answer_data` | text | JSON array of query result rows. On success: `[{"total_revenue": 12345.67, ...}]`. On no-data: `[]`. On error: `[{"raw": "Error: ..."}]` |
| `status` | varchar(20) | Execution outcome: `ok`, `no_data`, or `error` |
| `error_message` | text | Error details — populated only when `status = 'error'` |

### `answer_data` Format by `answer_type`

The value in `answer_data` is always a JSON array. The inner dict keys depend on the SQL that was generated:

| `answer_type` | Typical shape |
|---|---|
| `SUMMARY_CARD` | Single-row array: `[{"total_revenue": 5000.0, "total_orders": 120, ...}]` |
| `YOY_CHECK` | Single-row KPI with year-over-year metric: `[{"this_year": 5000, "last_year": 4200, "pct_change": 19.0}]` |
| `RANKED_TABLE` | Multi-row array ordered by rank metric: `[{"sku": "LED-001", "total_revenue": 800}, ...]` |
| `FLAG_TABLE` | Multi-row array of flagged items: `[{"sku": "LED-999", "days_cover": 2, ...}, ...]` |
| `OPPORTUNITY_LIST` | Multi-row array of opportunity items (same shape as `FLAG_TABLE`) |
| `PLATFORM_BREAKDOWN` | Multi-row array, one row per platform: `[{"platform": "AMAZON", "revenue": 3000}, ...]` |
| `CONCENTRATION_CHECK` | One or many rows depending on query — could be a single KPI or a ranked set |

### Key Query Patterns

#### Get all answers for a user on the latest run date
```sql
SELECT question_no, question, category, answer_type, answer_data, status, error_message
FROM development.user_answers
WHERE user_name = 'Saranya'
  AND run_date = (SELECT MAX(run_date) FROM development.user_answers WHERE user_name = 'Saranya')
ORDER BY question_no;
```

#### Get all errors for a specific date
```sql
SELECT user_name, question_no, question, error_message
FROM development.user_answers
WHERE status = 'error'
  AND run_date = '2026-05-21'
ORDER BY user_name, question_no;
```

#### Count answered vs no_data vs error per user on latest run
```sql
SELECT user_name,
       SUM(CASE WHEN status = 'ok'      THEN 1 ELSE 0 END) AS answered,
       SUM(CASE WHEN status = 'no_data' THEN 1 ELSE 0 END) AS no_data,
       SUM(CASE WHEN status = 'error'   THEN 1 ELSE 0 END) AS errors
FROM development.user_answers
WHERE run_date = (SELECT MAX(run_date) FROM development.user_answers)
GROUP BY user_name
ORDER BY user_name;
```

#### Get all distinct run dates
```sql
SELECT DISTINCT run_date
FROM development.user_answers
ORDER BY run_date DESC;
```

### Key Business Rules

- **Latest run date** → always use `MAX(run_date)` subquery — never hardcode a date
- **Status values** → `ok` (data returned), `no_data` (zero rows), `error` (query or MCP failed)
- **answer_data on error** → may contain `[{"raw": "Error: ..."}]` — treat as failed, not as real data
- **Deduplication** → `save_user_answer()` deletes then re-inserts for the same `(user_name, run_date, question_no)` triple. No UNIQUE constraint — Python enforces idempotency. Re-running Step 3 on the same day overwrites that day's answers
- **question_no range** → 1–28, matching `generated_sqls.question_no` and the Google Sheet row order

---

## Table 2: `development.answer_comparisons`

### Purpose
Stores the comparison result for every user × question pair between the current run date and the immediately preceding run date. One row per `(run_date, user_name, question_no)` — enforced by a UNIQUE constraint.

### Schema

| Column | Type | Description |
|---|---|---|
| `id` | serial | Auto-increment primary key |
| `created_at` | timestamp | Exact datetime this comparison row was written |
| `run_date` | date | The current run date being compared. Format: `YYYY-MM-DD` |
| `prev_date` | date | The previous run date used as the baseline. Format: `YYYY-MM-DD` |
| `user_name` | varchar(200) | The seller/user this comparison belongs to |
| `question_no` | integer | Question number |
| `question` | text | Full question text |
| `answer_type` | varchar(50) | Rendering type. Valid values: `SUMMARY_CARD`, `RANKED_TABLE`, `FLAG_TABLE`, `OPPORTUNITY_LIST`, `PLATFORM_BREAKDOWN`, `CONCENTRATION_CHECK`, `YOY_CHECK` |
| `comparison_text` | text | Human-readable comparison summary using arrows and symbols (↑ ↓ → ✓ ✗) |
| `comparison_data` | text | JSON object of structured insight metrics. Shape varies by `answer_type` — see section below |
| `direction` | varchar(10) | Overall direction of the comparison: `up` (improvement), `down` (decline), or `flat` (no significant change) |

### Unique Constraint

```sql
CONSTRAINT uidx_cmp UNIQUE (run_date, user_name, question_no)
```

`save_comparison()` uses `ON CONFLICT DO NOTHING`. Running Step 4 multiple times on the same day is safe — existing rows are never overwritten.

### `comparison_data` Format by `answer_type`

#### `SUMMARY_CARD` / `YOY_CHECK` → `_cmp_kpi()`
One key per numeric metric that changed by ≥1%:
```json
{
  "total_revenue": {"prev": 4200.0, "curr": 5100.0, "change_pct": 21.4},
  "total_orders":  {"prev": 110,    "curr": 130,    "change_pct": 18.2}
}
```

#### `FLAG_TABLE` / `OPPORTUNITY_LIST` → `_cmp_set_table()`
Set-level counts:
```json
{
  "total_curr": 7,
  "total_prev": 5,
  "new": 3,
  "cleared": 1,
  "ongoing": 4
}
```

#### `RANKED_TABLE` → `_cmp_ranked()`
Rank-movement counts plus set deltas:
```json
{
  "total_curr": 10,
  "total_prev": 9,
  "new": 2,
  "dropped": 1,
  "rank_improved": 4,
  "rank_worsened": 3
}
```

#### `PLATFORM_BREAKDOWN` → `_cmp_platform()`
One key per platform × metric pair that had the biggest change:
```json
{
  "AMAZON_total_revenue": {"prev": 3000.0, "curr": 3800.0, "change_pct": 26.7},
  "EBAY_total_revenue":   {"prev": 1200.0, "curr": 950.0,  "change_pct": -20.8}
}
```

#### `CONCENTRATION_CHECK`
Dispatches to `_cmp_kpi()` for single-row results or `_cmp_set_table()` for multi-row results.

### `comparison_text` Examples by `direction`

| `direction` | Example `comparison_text` |
|---|---|
| `up` | `↑ Revenue: £4,200 → £5,100 (+21.4%)` / `↑ Orders: 110 → 130 (+18.2%)` |
| `down` | `↓ Revenue: £5,100 → £3,900 (-23.5%)` / `✗ 3 new flagged SKUs: LED-001, LED-002 +1 more` |
| `flat` | `→ No significant change vs previous run` |

### Key Query Patterns

#### Get all comparisons for a user on the latest run date
```sql
SELECT question_no, answer_type, comparison_text, comparison_data, direction, prev_date
FROM development.answer_comparisons
WHERE user_name = 'Saranya'
  AND run_date = (SELECT MAX(run_date) FROM development.answer_comparisons WHERE user_name = 'Saranya')
ORDER BY question_no;
```

#### Get all comparisons for a specific date (all users)
```sql
SELECT user_name, question_no, direction, comparison_text
FROM development.answer_comparisons
WHERE run_date = '2026-05-21'
ORDER BY user_name, question_no;
```

#### Count direction distribution for a run date
```sql
SELECT direction, COUNT(*) AS count
FROM development.answer_comparisons
WHERE run_date = '2026-05-21'
GROUP BY direction;
```

#### Find all down-direction comparisons (alerts)
```sql
SELECT user_name, question_no, question, comparison_text
FROM development.answer_comparisons
WHERE run_date = (SELECT MAX(run_date) FROM development.answer_comparisons)
  AND direction = 'down'
ORDER BY user_name, question_no;
```

### Key Business Rules

- **Latest run date** → always use `MAX(run_date)` subquery — never hardcode a date
- **direction values** → `up` (first line contains ↑ or ✓), `down` (first line contains ↓ or ✗), `flat` (no significant change)
- **Idempotency** → `ON CONFLICT DO NOTHING` means re-running Step 4 on the same day never overwrites existing rows
- **prev_date** → derived at write time as `MAX(run_date) WHERE run_date < current run_date` from `user_answers`; not recomputed on read

---

## Table Relationship

```
user_answers (run_date, user_name, question_no)  →  answer_comparisons (run_date, user_name, question_no)
```

`get_pending_comparison_pairs()` self-joins `user_answers` on `user_name + question_no` across two different `run_date` values, then left-joins `answer_comparisons` to find pairs not yet compared. The `answer_data` TEXT from both the current and previous `user_answers` rows is deserialized and passed to `generate_comparison()`.

| Table | Relationship |
|---|---|
| `user_answers` | Source of `curr_data` and `prev_data` for comparisons — read via `_load_answer_data()` before comparison |
| `answer_comparisons` | Reads `answer_data` from `user_answers` to compute curr vs prev deltas in Step 4 |