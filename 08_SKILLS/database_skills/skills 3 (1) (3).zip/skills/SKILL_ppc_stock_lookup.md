---
name: ppc-stock-lookup
description: "Use this skill when the user wants to find stock/inventory levels for ASINs or eBay item_ids or Shopify products that come from PPC data. All channels use ppc_performance as the source table. Covers the full bridge logic via ebay_products (wrong_sku check, mapped_sku fallback) → location_wise_inv_stock or inv_final_stock filtered by warehouse location. Amazon & eBay bridge on ref_id; Shopify bridges on sku column. Applies to Amazon (which_channel=1), eBay (which_channel=2), Shopify (which_channel=3)."
---

# PPC → Stock Lookup Skill

## Overview

When a user wants stock for PPC listings, **do not use `order_transaction` as a bridge**. Use the `ebay_products` table — it is the correct mapping table linking `ref_id` (ASIN / item_id) or Shopify SKU to inventory SKU, per channel and marketplace.

> ⚠️ Shopify uses a **different PPC source table** and a **different bridge key** — see the Shopify section below.

---

## Channel Quick Reference

| Channel | Source Table | Bridge Key into ebay_products | which_channel |
|---|---|---|---|
| Amazon | `ppc_performance` | `ref_id` | 1 |
| eBay | `ppc_performance` | `ref_id` | 2 |
| Shopify | `ppc_performance` | `sku` column (not `ref_id`) | 3 |

---

## Full Lookup Flow — Amazon & eBay

```
ppc_performance  (ref_id + marketplace + source + sub_source_id)
        ↓
   JOIN ON:
   ppc.ref_id        = ebay_products.ref_id
   ppc.source        = ebay_products.which_channel
   ppc.sub_source_id = ebay_products.sub_source
   ppc.marketplace   = ebay_products.market_place
   + wrong_sku = 0
        ↓
ebay_products  (resolve SKU → mapped_sku if not NULL, else sku)
        ↓
warehouse location mapping (marketplace → UK / Germany / US)
        ↓
location_wise_inv_stock  (default, by location)
inv_final_stock          (only if specific warehouse asked)
```

---

## Step 1 — Get ref_id from PPC

From `public.ppc_performance`, extract:
- `ref_id` — ASIN (Amazon) or item_id (eBay)
- `marketplace` — used later for warehouse location mapping
- `source` — 1 = Amazon, 2 = eBay, 3 = Shopify
- `sub_source_id` — sub-source identifier

Filter: `WHERE "ref_id" != '0'`

---

## Step 2 — Look Up SKU in `ebay_products`

Table: `public.ebay_products`

### Key Columns

| Column | Description |
|---|---|
| `ref_id` | ASIN or eBay item_id |
| `which_channel` | 1 = Amazon, 2 = eBay |
| `market_place` | Marketplace (e.g. UK, Germany) |
| `sub_source` | Sub-source ID |
| `sku` | Listing SKU (may be a listing/variant SKU) |
| `mapped_sku` | Inventory SKU — use this if not NULL (Amazon only mismatch issue) |
| `wrong_sku` | 0 = valid, 1 = invalid — ALWAYS filter `wrong_sku = 0` |

### Lookup Rules

```
WHERE ref_id     = '<ref_id from ppc>'
  AND which_channel = <1 for Amazon, 2 for eBay>
  AND wrong_sku  = 0
```

### SKU Resolution Logic

```
IF mapped_sku IS NOT NULL AND mapped_sku != ''
    → use mapped_sku   (inventory SKU — corrected mapping)
ELSE
    → use sku          (use as-is)
```

> ⚠️ The `mapped_sku` exists because Amazon PPC listings may use a **listing SKU** that differs from the **inventory SKU** in the warehouse system. This mismatch does NOT occur for eBay or Shopify.

### Channel-Specific Notes

| Channel | which_channel | SKU variations | mapped_sku needed? |
|---|---|---|---|
| Amazon | 1 | Usually one SKU per ASIN | Yes — check mapped_sku always |
| eBay | 2 | Can have **multiple SKU rows** per item_id (variants) | No — use sku directly |

For eBay: collect **all valid SKUs** (all rows with `wrong_sku = 0`) and look up stock for each one individually.

---

## Step 3 — Map PPC Marketplace → Warehouse Location

`inv_final_stock` is filtered by `warehouse_location`. Use this mapping from PPC `marketplace`:

| PPC Marketplace | warehouse_location |
|---|---|
| UK | UK |
| US, Canada, Mexico | US |
| Germany, France, Spain, Italy, Austria, Netherlands, Belgium, Belgium_Dutch, Belgium_French, Poland, Sweden, Switzerland, Saudi Arabia, United Arab Emirates, Ireland | Germany |

Apply as: `WHERE "warehouse_location" = '<mapped location>'`

---

## Step 4 — Choose the Right Stock Table

There are **two inventory tables**. Choose based on what the user is asking:

| User asks for... | Table to use |
|---|---|
| Stock by **location / region** (e.g. "UK stock", "Germany stock") | `public.location_wise_inv_stock` |
| Stock by **warehouse** (e.g. "UK Unit3", "Duisburg warehouse") or general stock | `public.inv_final_stock` |

> **Default:** If the user does not mention a specific warehouse, use `location_wise_inv_stock` first — it is the cleaner location-level view.

---

### Table A — `public.location_wise_inv_stock` (Location Level)

#### Schema

| Column | Type | Description |
|---|---|---|
| `id` | bigint | Primary key |
| `sku` | text | SKU |
| `stock` | bigint | Stock quantity at this location |
| `location` | text | `UK`, `Germany`, `US` |
| `updated_at` | timestamp | Last updated timestamp |

#### Query Pattern

```sql
SELECT "sku", SUM(COALESCE("stock", 0)) AS total_stock
FROM public.location_wise_inv_stock
WHERE "sku" IN (<resolved SKU(s)>)
  AND "location" = '<mapped location>'
GROUP BY "sku"
```

- `location` values: `UK`, `Germany`, `US` — matches directly to the warehouse location mapping in Step 3
- Always `SUM(COALESCE("stock", 0))` in case of multiple rows per SKU per location

---

### Table B — `public.inv_final_stock` (Warehouse Level)

Use **only** when the user explicitly asks about a specific warehouse or wants stock broken down by individual warehouse.

#### Query Pattern

```sql
SELECT "sku", "warehouse_name", SUM(COALESCE("stock", 0)) AS total_stock
FROM public.inv_final_stock
WHERE "sku" IN (<resolved SKU(s)>)
  AND "warehouse_location" = '<mapped location>'
GROUP BY "sku", "warehouse_name"
```

- Filter by `warehouse_location` (matches the same mapping as `location` above)
- Group by `warehouse_name` when breakdown is needed
- If zero rows returned → SKU not stocked in that location; report as 0

---

# Full Example — Amazon (Germany)

## Step 1 — Get ref_id from ppc_performance

```sql
SELECT DISTINCT ref_id, marketplace, source, sub_source_id
FROM public.ppc_performance
WHERE source = 1
  AND ref_id = 'B015RLJ1CE'
```

**Result:**

| ref_id | marketplace | source | sub_source_id |
|---|---|---|---|
| `B015RLJ1CE` | `Germany` | `1` | `8` |

---

## Step 2 — Look Up SKU in ebay_products

```sql
SELECT sku, mapped_sku, wrong_sku
FROM public.ebay_products
WHERE ref_id      = 'B015RLJ1CE'
  AND market_place  = 'Germany'
  AND which_channel = 1
  AND sub_source    = 8
  AND wrong_sku     = 0
```

**Result:**

| sku | mapped_sku | wrong_sku |
|---|---|---|
| `CRFF100GB-IDE` | `NULL` | `0` |
| `CRFF100GB` | `CRFF100GB` | `0` |
| `TG-8PWN-DLZP` | `CRFF100GB` | `0` |

**SKU Resolution:**
- Multiple rows returned — all `mapped_sku` values point to `CRFF100GB`
- `mapped_sku` is not NULL → use **`CRFF100GB`**

---

## Step 3 — Marketplace → Warehouse Location Mapping

| PPC Marketplace | Warehouse Location |
|---|---|
| Germany | `Germany` |

→ Use `location = 'Germany'`

---

## Step 4 — Get Stock

```sql
SELECT sku, SUM(COALESCE(stock, 0)) AS total_stock
FROM public.location_wise_inv_stock
WHERE sku      = 'CRFF100GB'
  AND location = 'Germany'
GROUP BY sku
```

**Result:**

| sku | total_stock |
|---|---|
| `CRFF100GB` | **63 units** ✅ |
---

# Full Examples — eBay

---

## Example 1 — eBay Single SKU (UK)

### Step 1 — Get ref_id from ppc_performance

```sql
SELECT DISTINCT ref_id, marketplace, source, sub_source_id
FROM public.ppc_performance
WHERE source = 2
  AND ref_id = '161762916766'
```

**Result:**

| ref_id | marketplace | source | sub_source_id |
|---|---|---|---|
| `161762916766` | `UK` | `2` | `1` |

---

### Step 2 — Look Up SKU in ebay_products

```sql
SELECT sku, mapped_sku, wrong_sku
FROM public.ebay_products
WHERE ref_id       = '161762916766'
  AND market_place  = 'UK'
  AND which_channel = 2
  AND sub_source    = 1
  AND wrong_sku     = 0
```

**Result:**

| sku | mapped_sku | wrong_sku |
|---|---|---|
| `LDMA60B224WW2PK` | `NULL` | `0` |

**SKU Resolution:**
- Single row returned
- `mapped_sku` is NULL → use **`LDMA60B224WW2PK`** directly

---

### Step 3 — Marketplace → Warehouse Location Mapping

| PPC Marketplace | Warehouse Location |
|---|---|
| UK | `UK` |

→ Use `location = 'UK'`

---

### Step 4 — Get Stock

```sql
SELECT sku, SUM(COALESCE(stock, 0)) AS total_stock
FROM public.location_wise_inv_stock
WHERE sku      = 'LDMA60B224WW2PK'
  AND location = 'UK'
GROUP BY sku
```

**Result:**

| sku | total_stock |
|---|---|
| `LDMA60B224WW2PK` | **18 units** ✅ |

---
---

## Example 2 — eBay Multi-SKU (Germany)

### Step 1 — Get ref_id from ppc_performance

```sql
SELECT DISTINCT ref_id, marketplace, source, sub_source_id
FROM public.ppc_performance
WHERE source = 2
  AND ref_id = '265660353904'
```

**Result:**

| ref_id | marketplace | source | sub_source_id |
|---|---|---|---|
| `265660353904` | `Germany` | `2` | `22` |

---

### Step 2 — Look Up SKU in ebay_products

```sql
SELECT sku, mapped_sku, wrong_sku
FROM public.ebay_products
WHERE ref_id       = '265660353904'
  AND market_place  = 'Germany'
  AND which_channel = 2
  AND sub_source    = 22
  AND wrong_sku     = 0
```

**Result — 26 SKU rows (colour variants):**

| sku | mapped_sku | wrong_sku |
|---|---|---|
| `CL3RRE-IDE` | `NULL` | `0` |
| `CL3RBL-IDE` | `NULL` | `0` |
| `CL3RGR-IDE` | `NULL` | `0` |
| `…` (26 rows total) | `NULL` | `0` |
| `CL3RRH-IDE` | `NULL` | `0` |

**SKU Resolution:**
- All 26 rows have `mapped_sku = NULL` → use `sku` directly for each
- Collect ALL SKUs and pass as `IN (...)` to stock query

---

### Step 3 — Marketplace → Warehouse Location Mapping

| PPC Marketplace | Warehouse Location |
|---|---|
| Germany | `Germany` |

→ Use `location = 'Germany'`

---

### Step 4 — Get Stock

```sql
SELECT sku, SUM(COALESCE(stock, 0)) AS total_stock
FROM public.location_wise_inv_stock
WHERE sku IN (
    'CL3RRE-IDE', 'CL3RBL-IDE', 'CL3RGR-IDE', 'CL3RGY-IDE',
    'CL3RWH-IDE', 'CL3RBM-IDE', 'CL3RYE-IDE', 'CL3RGD-IDE',
    'CL3RLG-IDE', 'CL3RBK-IDE', 'CL3ROR-IDE', 'CL3RRS-IDE',
    'CL3RBU-IDE', 'CL3RRO-IDE', 'CL3RBT-IDE', 'CL3RLB-IDE',
    'CL3RGCR',    'CL3RHE-IDE', 'CL3RBP-IDE', 'CL3RSI-IDE',
    'CL3RPU-IDE', 'CL3RBW-IDE', 'CL3RIV-IDE', 'CL3RMU-IDE',
    'CL3RPI-IDE', 'CL3RRH-IDE'
  )
  AND location = 'Germany'
GROUP BY sku
ORDER BY total_stock DESC
```

**Result:**

| sku | total_stock |
|---|---|
| `CL3RGCR` | **0 units** |
| All other 25 SKUs | **0 units** (no stock record found) |

> All variants are currently out of stock in Germany warehouse.
---

## SQL Rules

- Always `wrong_sku = 0` filter on `ebay_products` — never skip this
- Always resolve `mapped_sku` before using `sku`
- Always filter stock tables by location — never return global stock for a PPC marketplace query
- Always `SUM(COALESCE("stock", 0))` — never bare SUM
- For eBay: collect ALL SKU rows and pass them as `IN (...)` to stock query
- **Shopify:** same `ppc_performance` table (source=3), but use `sku` column (not `ref_id`) as bridge key into `ebay_products.ref_id`; skip rows where `sku = '0'`
- **Stock table routing:**
  - User asks by location/region → `public.location_wise_inv_stock` filtered by `location`
  - User asks by specific warehouse → `public.inv_final_stock` filtered by `warehouse_location`
  - No preference stated → default to `public.location_wise_inv_stock`
- Execute all queries via `postgres:execute_sql` — never show SQL alone as final answer

---

# Full Example — Shopify (UK)

## Key Difference vs Amazon & eBay

| | Amazon & eBay | Shopify |
|---|---|---|
| Bridge key from ppc_performance | `ref_id` | `sku` column |
| Filter | `ref_id != '0'` | `sku != '0'` |
| which_channel in ebay_products | `1` or `2` | `3` |



## Step 1 — Get SKU from ppc_performance

> ⚠️ For Shopify use the `sku` column as the bridge key — NOT `ref_id`

```sql
SELECT DISTINCT sku, marketplace, source, sub_source_id
FROM public.ppc_performance
WHERE source = 3
  AND sku != '0'
```

**Result:**

| sku | marketplace | source | sub_source_id |
|---|---|---|---|
| `19727805710432` | `UK` | `3` | `109` |

---

## Step 2 — Look Up in ebay_products

> ⚠️ Match `ppc_performance.sku` → `ebay_products.ref_id` (not ref_id → ref_id)

```sql
SELECT ref_id, sku, mapped_sku, wrong_sku
FROM public.ebay_products
WHERE ref_id       = '19727805710432'
  AND market_place  = 'UK'
  AND which_channel = 3
  AND sub_source    = 109
  AND wrong_sku     = 0
```

**Result:**

| ref_id | sku | mapped_sku | wrong_sku |
|---|---|---|---|
| `19727805710432` | `CRSF100BM+PHTT1PBRBM+LSCF350BM` | `NULL` | `0` |

**SKU Resolution:**
- `mapped_sku` is NULL → use **`CRSF100BM+PHTT1PBRBM+LSCF350BM`** directly

---

## Step 3 — Marketplace → Warehouse Location Mapping

| PPC Marketplace | Warehouse Location |
|---|---|
| UK | `UK` |

→ Use `location = 'UK'`

---

## Step 4 — Get Stock

```sql
SELECT sku, SUM(COALESCE(stock, 0)) AS total_stock
FROM public.location_wise_inv_stock
WHERE sku      = 'CRSF100BM+PHTT1PBRBM+LSCF350BM'
  AND location = 'UK'
GROUP BY sku
```

**Result:**

| sku | total_stock |
|---|---|
| `CRSF100BM+PHTT1PBRBM+LSCF350BM` | **0 units** |

> Currently out of stock in the UK warehouse.